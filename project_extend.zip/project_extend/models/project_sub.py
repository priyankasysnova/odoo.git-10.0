'''
Created on Aug 24, 2020

@author: priyanka
'''
from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools.safe_eval import safe_eval
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError

_STATES = [
    ('draft', 'Draft'),
    ('approved', 'Approved'),
    ('rejected', 'Rejected')
]

class ProjectSub(models.Model):
    _name = "project.sub"
    _description = "Sub Project"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = "name, id"
    
    
    @api.depends('material_costs.project_sub_id','fixed_costs.project_sub_id')
    def _compute_cost(self):
        for line in self:
            cost = 0.0
            for inv_line in line.material_costs:
                print inv_line.product_uom_id
                cost += inv_line.product_uom_id._compute_quantity(inv_line.product_qty, inv_line.product_uom_id)*inv_line.amount
                
            for inv_line in line.fixed_costs:
                print inv_line.product_uom_id
                cost += inv_line.product_uom_id._compute_quantity(inv_line.product_qty, inv_line.product_uom_id)*inv_line.amount
   
            
                
            line.estimated_cost = cost
    
    
    name = fields.Char(string='Name', track_visibility='always', required=True, index=True)
    project_id = fields.Many2one('project.project',
        string='Project',index=True,track_visibility='onchange',change_default=True)
    state = fields.Selection(selection=_STATES,
                             string='Status',
                             index=True,
                             track_visibility='onchange',
                             required=True,
                             copy=False,
                             default='draft')
    start_date = fields.Date('Planned Start Date',default=fields.Date.context_today,
                         track_visibility='onchange')
    end_date = fields.Date('Planned End Date',
                        default=fields.Date.context_today,
                         track_visibility='onchange')
    ac_start_date = fields.Date('Actual Start Date',
                        default=fields.Date.context_today,
                         track_visibility='onchange')
    ac_end_date = fields.Date('Actual End Date',
                        default=fields.Date.context_today,
                         track_visibility='onchange')
    estimated_cost = fields.Float(compute='_compute_cost',string="Estimated Cost", digits=dp.get_precision('Product Unit of Measure'), store=True)
    actual_cost = fields.Float('Actual Cost', track_visibility='onchange',
                               digits=dp.get_precision(
                                   'Product Unit of Measure'))
    
    
    @api.multi
    def button_approved(self):
        for rec in self:
            rec.state = 'approved'
            
        return True
    
    @api.multi
    def button_rejected(self):
        for rec in self:
            rec.state = 'rejected'
        return True
    
class project_extend(models.Model):

    _inherit = 'project.project'
    
    @api.depends('sub_project_ids.state')
    def _compute_cost(self):
        for line in self:
            cost = 0.0
            for inv_line in line.sub_project_ids:
                if inv_line.state in ['approved']:
                    cost += inv_line.estimated_cost
                
            line.estimated_cost = cost
    
    
    sub_project_ids=fields.One2many('project.sub', 'project_id', 'Sub Projects')
    estimated_cost = fields.Float(compute='_compute_cost',string="Estimated Cost", digits=dp.get_precision('Product Unit of Measure'), store=True)
    actual_cost = fields.Float('Actual Cost', track_visibility='onchange',
                               digits=dp.get_precision(
                                   'Product Unit of Measure'))


project_extend()    
