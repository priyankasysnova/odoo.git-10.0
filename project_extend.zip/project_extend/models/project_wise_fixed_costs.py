'''
Created on Dec 27, 2017

@author: openerp
'''

import odoo.addons.decimal_precision as dp
from odoo import api, fields, models

class ProjectWiseFixedCosts(models.Model):
    _name = 'project.fixed.costs'
    
    @api.depends('product_qty','amount')
    def _compute_total(self):
        for line in self:
            total =  (line.product_qty * line.amount)
            line.update({
                'subtotal': total,
            })

    name = fields.Char('Description', size=128)
    amount = fields.Float('Amount', digits_compute=dp.get_precision('Account'))
    product_id = fields.Many2one('product.product', 'Service', required=True)
    product_qty = fields.Float(string='Quantity', required=True, default=1.0)
    product_uom_id = fields.Many2one('product.uom', 'Product Unit of Measure',
                                     track_visibility='onchange')
    subtotal = fields.Float(compute='_compute_total', string='Subtotal', readonly=True, store=True)
    project_sub_id = fields.Many2one('project.sub','Sub Project',ondelete='cascade', readonly=True)



    @api.onchange('product_id')
    def product_id_change(self):
        if self.product_id:
            name = self.product_id.name
            if self.product_id.code:
                name = '[%s] %s' % (name, self.product_id.code)
            if self.product_id.description_purchase:
                name += '\n' + self.product_id.description_purchase
            self.product_uom_id = self.product_id.uom_id.id
            self.product_qty = 1
            self.name = name
    
ProjectWiseFixedCosts()

class subproject_material_costs(models.Model):

    _inherit = 'project.sub'
    
    fixed_costs=fields.One2many('project.fixed.costs', 'project_sub_id', 'Fixed costs')


subproject_material_costs()