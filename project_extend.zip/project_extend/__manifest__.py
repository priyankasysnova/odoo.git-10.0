# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Project Extension',
    'version': '1.0',
    'category': 'Project',
    'sequence': 40,
    'summary': '',
    'description': """ Incorporate Sub project module. It will be under Project. One project can have multiple sub
project. Every sub project should have a name and budget line can be added in sub project""",
    'website': '',
    'depends': [
        'project',
    ],
    'data': [
        'views/project_sub_view.xml',
        'views/project_extend.xml',
    ],
    'demo': [],
    'application': True,
}
